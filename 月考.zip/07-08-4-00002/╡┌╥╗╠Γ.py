import pandas as pd
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.metrics import roc_curve
import matplotlib.pyplot as ht
# 1.读取给定的乳腺癌生数据(没有预处理的数据)
s=pd.read_csv('breast-cancer-wisconsin.data',header=None)
# 2查看前五条数据，
print(s.head())
# 3查看数据信息，
s.info()
# 4数据描述
print(f'数据描述',s.describe())
# 5查看后五条数据
print(f'后五条数据',s.tail())
# 6将出现?的那一列，将?改成1
s.replace('?',1,inplace=True)
# 7将 第六列 类型 转换为一般整型
s[6]=s[6].astype(int)

# 8将 标签列 中 2,4类别改成 0，1类别，使用字典实现
s[10]=s[10].map({2:0,4:1})
print(s[10])
# 9使用value_count方法，查看 正样本 和 负样本 类别 是否平衡
print(s[10].value_counts())
# 10从 正样本中，随机抽取出 差值个 正样本，和原先的数据组装成一个新的数据帧
ss=s[s[10]==1].sample(458-241)
s=pd.concat([ss,s])
print(s[10].value_counts())
# 11分别取出特征和标签
y=s.pop(10)
x=s
# 12特征 标准化 处理
x=StandardScaler().fit_transform(x)
trainx,testx,trainy,testy=train_test_split(x,y)
# 13创建逻辑回归模型，
lo=LogisticRegression()
# 14使用 网格搜索交叉验证 寻找 逻辑回归超参数中 正则化系数C的最佳取值
model=GridSearchCV(lo,param_grid={'C':[0.1,0.3,0.5,1.0,1.5]})
model.fit(trainx,trainy)
# 15打印最优参数
print(f'最优参数',model.best_params_)
# 16打印最优得分
print(f'最优得分',model.best_score_)
# 17重新 使用 最佳参数 实例化 逻辑回归模型对象并且训练模型
lo=LogisticRegression(C=model.best_params_['C'])
lo.fit(trainx,trainy)
# 18输出测试集的预测中，某个样本属于0类别 还是1类别的概率
lb=lo.predict_proba(testx)
print(lb)
# 19调用ROC曲线方法
a,b,c=roc_curve(testy,lo.predict(testx))
# 20绘制roc曲线
ht.plot(a,b)
ht.show()

