# 第二题：
import numpy as np
import matplotlib.pyplot as ht
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split,GridSearchCV
from sklearn.linear_model import Ridge
from sklearn.metrics import r2_score,mean_squared_error,mean_absolute_error
# 用fangjia.txt进行数据预测

# 1、读取数据
s=np.loadtxt('fangjia.txt',delimiter=',')
# 2、进行数据特征和标签切分
x=s[:,:-1]
y=s[:,-1:]
# 3、使用留出法，将数据分为训练集和测试集
trainx,testx,trainy,testy=train_test_split(x,y)
# 4、将特征进行标准化处理
trainx=StandardScaler().fit_transform(trainx)
testx=StandardScaler().fit_transform(testx)
# 5、创建线性回归模型（使用岭回归）
li=Ridge()
# 6、使用不同alpha数值计算0.01, 0.05,0.1,0.3,0.6,1
model=GridSearchCV(li,param_grid={'alpha':[0.01, 0.05,0.1,0.3,0.6,1]})
model.fit(trainx,trainy)
# 7、输出最优数值
print(f'最优参数',model.best_params_)
# 8、打印预测值
li=Ridge(alpha=model.best_params_['alpha'])
li.fit(trainx,trainy)
print(f'预测值',li.predict(testx))
# 9、打印权重和截距
print(f'截距',li.intercept_)
print(f'权重',li.coef_)
# 10、打印R方，mse，mae数据值
print(f'R方',r2_score(testy,li.predict(testx)))
print(f'mse',mean_squared_error(testy,li.predict(testx)))
print(f'mae',mean_absolute_error(testy,li.predict(testx)))